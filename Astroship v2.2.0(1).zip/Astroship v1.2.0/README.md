# Readme

Thank you for downloading this template. To get started, open Help Docs link to read the instructions on the documentation. The main project files are located in the _astroship_ folder.

## License

This template is licensed under the GNU General Public License v3.0.

## About

This template is designed and developed by [Web3Templates](https://web3templates.com).